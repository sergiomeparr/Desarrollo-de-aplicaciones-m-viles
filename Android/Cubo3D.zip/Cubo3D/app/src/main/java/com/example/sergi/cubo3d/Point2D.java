package com.example.sergi.cubo3d;

class Point2D{
    float x, y;
    Point2D(float x, float y){
        this.x = x;
        this.y = y;
    }
}

