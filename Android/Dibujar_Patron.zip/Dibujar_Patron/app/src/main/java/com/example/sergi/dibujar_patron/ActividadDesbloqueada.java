package com.example.sergi.dibujar_patron;

public class ActividadDesbloqueada {
}
